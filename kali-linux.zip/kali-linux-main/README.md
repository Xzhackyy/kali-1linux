# kali-linux

# running commands

#
pkg install git


#
git clone https://github.com/DRACULA-HACK/kali-linux

#
cd kali-linux

#

chmod +x install-nethunter-kali.sh

#

bash install-nethunter-kali.sh

#
